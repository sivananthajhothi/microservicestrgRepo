package com.boa.circuitbreaker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.boa.circuitbreaker.dto.JwtRequest;
import com.boa.circuitbreaker.handlers.HystrixHandler;

@RestController
public class CircuitBreakerController {
    @Autowired 
	private HystrixHandler hystrixHandler;
	
	@PostMapping("/cbcustomers")
	public ResponseEntity<?> getCustomers(@RequestBody JwtRequest jwtRequest)
	{
		ResponseEntity<String> response=hystrixHandler.requestHandler(jwtRequest);
		
		if(response.getBody().isEmpty())
			
	       return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Call not connected");
		else
			return response;
		
	}
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
}

