package com.boa.appointment.models;

public enum AppointmentType {
  Loan,KYC,Savings,Demat
}
