package com.boa.appointment.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.appointment.models.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

}
