package com.boa.appointment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.appointment.Repository.AppointmentRepository;
import com.boa.appointment.models.Appointment;


@Service
public class AppointmentService{
	@Autowired
	private AppointmentRepository appointmentRepository;
	
	//insert
	public Appointment addAppointment(Appointment appointment) {
		return appointmentRepository.save(appointment);
	}
	
	// select all
	public List<Appointment> getAllAppointments(){
		return this.appointmentRepository.findAll();
	}
	
	// get customer by id
	public Appointment getAppointmentById(long appointmentId) {
		return this.appointmentRepository.findById(appointmentId).orElse(null);
	}
	
	// delete customer id
	public boolean deleteAppointmentById(long appointmentId) {
			boolean status = true;
			this.appointmentRepository.deleteById(appointmentId);
			if(getAppointmentById(appointmentId)!=null)
					return false;
			return status;
			
	}
	//must pass customerId
	
		public Appointment updateappointment(Appointment appointment)
		{
			return this.appointmentRepository.save(appointment);
		}
}
